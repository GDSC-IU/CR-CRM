import React, { Component } from 'react';
import { Switch, Route, Link } from "react-router-dom";
import Login from './login';
import { Form, Button } from 'react-bootstrap';

class Employee extends Component {
  
	render() {

		return (
			<>
				
			</>
		);
	};

}


export default Employee;